/*
# Create portfolio database schema for Ravi Sharma's video editor site

1. Overview
   This is a single-tenant, no-auth portfolio website. There is no sign-in screen.
   All policies use `TO anon, authenticated` so the anon-key frontend can read/write.

2. New Tables
   - `projects`
     - Stores portfolio projects (title, category, description, tools, media paths, role, sort order).
     - Replaces the hardcoded project list in src/data/portfolio.ts so projects can be managed via the database.
     - Columns: id (slug, text PK), index, title, category, description, tools (text[]), thumbnail, poster, video, alt_text, role, sort_order, is_published, created_at, updated_at.
   - `project_inquiries`
     - Stores contact form submissions from potential clients.
     - Columns: id (uuid PK), name, email, project_type, message, is_read, created_at.

3. Security (RLS)
   - Both tables have RLS enabled.
   - `projects`: anyone can read published projects; only authenticated can insert/update/delete (admin manages via Supabase dashboard).
   - `project_inquiries`: anyone can submit a new inquiry (INSERT with CHECK true); only authenticated can read or update (so the site owner can review inquiries privately via the Supabase dashboard).

4. Important Notes
   - No auth flow is added — this is a public portfolio with no login.
   - The anon role can READ published projects and INSERT inquiries, but cannot read inquiries or modify projects.
   - `is_published` defaults to true so seeded projects appear immediately.
   - `is_read` on inquiries defaults to false so new messages are easy to spot.
*/

-- =============================================
-- Table: projects
-- =============================================
CREATE TABLE IF NOT EXISTS projects (
  id text PRIMARY KEY,
  index text NOT NULL,
  title text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  tools text[] NOT NULL DEFAULT '{}',
  thumbnail text NOT NULL,
  poster text,
  video text,
  alt_text text NOT NULL,
  role text,
  sort_order integer NOT NULL DEFAULT 0,
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

-- Anyone can read published projects
DROP POLICY IF EXISTS "public_read_projects" ON projects;
CREATE POLICY "public_read_projects"
  ON projects FOR SELECT
  TO anon, authenticated
  USING (is_published = true);

-- Only authenticated can insert
DROP POLICY IF EXISTS "auth_insert_projects" ON projects;
CREATE POLICY "auth_insert_projects"
  ON projects FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Only authenticated can update
DROP POLICY IF EXISTS "auth_update_projects" ON projects;
CREATE POLICY "auth_update_projects"
  ON projects FOR UPDATE
  TO authenticated
  USING (true) WITH CHECK (true);

-- Only authenticated can delete
DROP POLICY IF EXISTS "auth_delete_projects" ON projects;
CREATE POLICY "auth_delete_projects"
  ON projects FOR DELETE
  TO authenticated
  USING (true);

-- =============================================
-- Table: project_inquiries
-- =============================================
CREATE TABLE IF NOT EXISTS project_inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  project_type text,
  message text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE project_inquiries ENABLE ROW LEVEL SECURITY;

-- Anyone can submit an inquiry (public contact form)
DROP POLICY IF EXISTS "public_insert_inquiries" ON project_inquiries;
CREATE POLICY "public_insert_inquiries"
  ON project_inquiries FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Only authenticated can read inquiries (site owner reviews via dashboard)
DROP POLICY IF EXISTS "auth_read_inquiries" ON project_inquiries;
CREATE POLICY "auth_read_inquiries"
  ON project_inquiries FOR SELECT
  TO authenticated
  USING (true);

-- Only authenticated can update (mark as read)
DROP POLICY IF EXISTS "auth_update_inquiries" ON project_inquiries;
CREATE POLICY "auth_update_inquiries"
  ON project_inquiries FOR UPDATE
  TO authenticated
  USING (true) WITH CHECK (true);

-- Only authenticated can delete
DROP POLICY IF EXISTS "auth_delete_inquiries" ON project_inquiries;
CREATE POLICY "auth_delete_inquiries"
  ON project_inquiries FOR DELETE
  TO authenticated
  USING (true);

-- =============================================
-- Indexes
-- =============================================
CREATE INDEX IF NOT EXISTS idx_projects_sort_order ON projects (sort_order ASC);
CREATE INDEX IF NOT EXISTS idx_inquiries_created_at ON project_inquiries (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inquiries_is_read ON project_inquiries (is_read);

-- =============================================
-- Seed projects from existing portfolio data
-- =============================================
INSERT INTO projects (id, index, title, category, description, tools, thumbnail, poster, video, alt_text, role, sort_order, is_published)
VALUES
  ('timesphysio', '01', 'TimesPhysio', 'CLIENT WORK',
   'Edited video content for TimesPhysio — structured around clear messaging, clean pacing and a tone that fits a healthcare audience.',
   ARRAY['DaVinci Resolve', 'After Effects'],
   '/portfolio/timesphysio.jpg', '/portfolio/timesphysio.jpg', '/portfolio/timesphysio.mp4',
   'Physiotherapist treating a patient''s hand', 'Edit · Captions · Grade', 1, true),
  ('doctor-content', '02', 'Doctor Content', 'CLIENT WORK',
   'Talking-head edits for a doctor''s channel — tightening the delivery, adding B-roll, captions and motion to keep the message clear and watchable.',
   ARRAY['DaVinci Resolve', 'Photoshop'],
   '/portfolio/doctor.jpg', '/portfolio/doctor.jpg', '/portfolio/doctor.mp4',
   'Doctor reviewing a chest X-ray', 'Edit · B-roll · Captions', 2, true),
  ('podcast-edit', '03', 'Podcast Edit', 'PODCAST',
   'Full podcast edit — cleaning up the conversation, pacing the cuts, and building a rhythm that carries the dialogue without losing the natural flow.',
   ARRAY['DaVinci Resolve'],
   '/portfolio/podcast.jpg', '/portfolio/podcast.jpg', '/portfolio/podcast.mp4',
   'Professional microphone in a dim recording studio', 'Edit · Sound · Pacing', 3, true),
  ('3d-motion', '04', '3D Motion Graphic', 'MOTION DESIGN',
   'A 3D motion graphics piece built around form, light and movement — designed to show how motion can carry an idea on its own.',
   ARRAY['After Effects', 'DaVinci Resolve'],
   '/portfolio/3d-motion.jpg', '/portfolio/3d-motion.jpg', '/portfolio/3d-motion.mp4',
   'Abstract 3D geometric shapes in a dark render', 'Motion · 3D · Compositing', 4, true),
  ('talking-head-tutorial', '05', 'Talking Head / Tutorial', 'TUTORIAL',
   'Tutorial-style talking-head edit — clear structure, paced explanations, captions and motion that help the viewer follow each step.',
   ARRAY['DaVinci Resolve', 'After Effects'],
   '/portfolio/tutorial.jpg', '/portfolio/tutorial.jpg', '/portfolio/tutorial.mp4',
   'Video editing timeline on a computer screen', 'Edit · Captions · Motion', 5, true),
  ('car-edit', '06', 'Car Edit', 'PERSONAL / EXPERIMENTAL',
   'A personal, experimental car edit — focused on rhythm, sound design and visual pacing, built to push how motion and music work together.',
   ARRAY['DaVinci Resolve', 'After Effects'],
   '/portfolio/car.jpg', '/portfolio/car.jpg', '/portfolio/car.mp4',
   'Person standing near a car at night with glowing lights', 'Edit · Sound Design · Grade', 6, true)
ON CONFLICT (id) DO NOTHING;
