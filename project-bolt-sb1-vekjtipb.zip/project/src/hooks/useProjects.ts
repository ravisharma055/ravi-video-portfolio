import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { projects as fallbackProjects, type Project } from '@/data/portfolio';

type DBProject = {
  id: string;
  index: string;
  title: string;
  category: string;
  description: string;
  tools: string[];
  thumbnail: string;
  poster: string | null;
  video: string | null;
  alt_text: string;
  role: string | null;
  sort_order: number;
  is_published: boolean;
};

function mapProject(p: DBProject): Project {
  return {
    id: p.id,
    index: p.index,
    title: p.title,
    category: p.category,
    description: p.description,
    tools: p.tools ?? [],
    thumbnail: p.thumbnail,
    poster: p.poster ?? p.thumbnail,
    video: p.video ?? undefined,
    alt: p.alt_text,
    role: p.role ?? undefined,
  };
}

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>(fallbackProjects);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    (async () => {
      try {
        const { data, error } = await supabase
          .from('projects')
          .select('*')
          .eq('is_published', true)
          .order('sort_order', { ascending: true });

        if (!active) return;

        if (error) {
          setError(error.message);
          setProjects(fallbackProjects);
        } else if (data && data.length > 0) {
          setProjects(data.map(mapProject));
        } else {
          setProjects(fallbackProjects);
        }
      } catch {
        if (!active) return;
        setProjects(fallbackProjects);
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  return { projects, loading, error };
}
