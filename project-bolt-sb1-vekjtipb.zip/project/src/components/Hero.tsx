export function Hero() {
  return (
    <section
      id="top"
      className="relative min-h-[100svh] flex flex-col justify-end overflow-hidden grain"
    >
      {/* Background — restrained cinematic motion */}
      <div className="absolute inset-0 -z-10">
        <div
          className="absolute inset-0 bg-cover bg-center animate-drift"
          style={{
            backgroundImage:
              "url('https://images.pexels.com/photos/6497924/pexels-photo-6497924.jpeg?auto=compress&cs=tinysrgb&w=1920')",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/70 via-ink-950/55 to-ink-950" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/60 to-transparent" />
      </div>

      {/* Top meta row */}
      <div className="absolute top-24 sm:top-28 left-0 right-0 px-5 sm:px-8 lg:px-12">
        <div className="mx-auto max-w-[1600px] flex items-center justify-between text-[10px] sm:text-[11px] tracking-widest text-bone-400 uppercase">
          <span className="flex items-center gap-2">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-accent animate-pulse-soft" />
            Portfolio — 2026
          </span>
          <span className="hidden sm:inline">Video Editor · Story · Motion</span>
        </div>
      </div>

      {/* Hero content */}
      <div className="relative px-5 sm:px-8 lg:px-12 pb-16 sm:pb-20 lg:pb-28">
        <div className="mx-auto max-w-[1600px]">
          <p className="mb-6 text-[11px] sm:text-xs tracking-widest text-bone-300 uppercase animate-fade-in">
            Ravi Sharma — Video Editor
          </p>
          <h1 className="font-semibold text-display-xl text-bone-50 tracking-tightest text-balance">
            <span className="block animate-fade-up" style={{ animationDelay: '0.05s' }}>
              I EDIT
            </span>
            <span
              className="block text-accent animate-fade-up"
              style={{ animationDelay: '0.18s' }}
            >
              ATTENTION.
            </span>
          </h1>
          <p
            className="mt-7 max-w-xl text-base sm:text-lg text-bone-200 leading-relaxed animate-fade-up"
            style={{ animationDelay: '0.32s' }}
          >
            Video editing built around storytelling, pacing and visuals that
            make people stop scrolling.
          </p>
          <div
            className="mt-9 flex flex-col sm:flex-row gap-3 sm:gap-4 animate-fade-up"
            style={{ animationDelay: '0.44s' }}
          >
            <a
              href="#showreel"
              className="group inline-flex items-center justify-center gap-2.5 bg-bone-50 text-ink-950 text-[13px] tracking-wide font-medium px-6 py-3.5 rounded-full hover:bg-accent hover:text-bone-50 transition-colors duration-300"
            >
              <span className="w-2 h-2 rounded-full bg-accent group-hover:bg-bone-50 transition-colors" />
              WATCH MY WORK
            </a>
            <a
              href="#contact"
              className="inline-flex items-center justify-center gap-2 text-bone-100 text-[13px] tracking-wide font-medium px-6 py-3.5 rounded-full border border-white/15 hover:border-bone-100 hover:bg-white/5 transition-colors duration-300"
            >
              LET&rsquo;S WORK TOGETHER
            </a>
          </div>
        </div>
      </div>

      {/* Bottom scroll cue */}
      <div className="absolute bottom-6 right-5 sm:right-8 lg:right-12 hidden sm:flex items-center gap-3 text-[10px] tracking-widest text-bone-400 uppercase">
        <span>Scroll</span>
        <span className="block w-10 h-px bg-bone-400/40" />
      </div>
    </section>
  );
}
