import { ArrowUpRight } from 'lucide-react';
import { about } from '@/data/portfolio';
import { Reveal } from './Reveal';

export function About() {
  return (
    <section id="about" className="relative py-24 sm:py-32 lg:py-40 px-5 sm:px-8 lg:px-12 border-t border-white/5">
      <div className="mx-auto max-w-[1600px] grid lg:grid-cols-12 gap-12 lg:gap-20 items-start">
        <Reveal className="lg:col-span-7">
          <p className="text-[11px] tracking-widest text-accent uppercase mb-5">About Ravi</p>
          <h2 className="font-semibold text-display-lg text-bone-50 tracking-tightest text-balance leading-[0.95]">
            {about.headline}
          </h2>
          <div className="mt-10 max-w-xl space-y-5 text-base sm:text-lg text-bone-300 leading-relaxed">
            {about.body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
          </div>
          <div className="mt-10 flex flex-wrap gap-2">
            {about.tools.map((tool) => (
              <span key={tool} className="border border-white/10 rounded-full px-4 py-2 text-xs tracking-wide text-bone-200">{tool}</span>
            ))}
          </div>
        </Reveal>

        <Reveal variant="scale" className="lg:col-span-4 lg:col-start-9">
          <div className="relative aspect-[4/5] max-w-md ml-auto overflow-hidden rounded-xl bg-ink-800">
            <img src={about.portrait} alt={about.alt} loading="lazy" className="w-full h-full object-cover grayscale contrast-110 opacity-80" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-950/75 via-transparent to-ink-950/10" />
            <span className="absolute bottom-5 left-5 text-[10px] tracking-widest text-bone-300 uppercase">Ravi Sharma / Editor</span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function WhyRavi() {
  return (
    <section className="relative py-20 sm:py-28 lg:py-36 px-5 sm:px-8 lg:px-12 bg-ink-900/40 border-y border-white/5">
      <div className="mx-auto max-w-[1600px]">
        <Reveal className="mb-14 sm:mb-20 flex flex-col md:flex-row md:items-end md:justify-between gap-5">
          <div>
            <p className="text-[11px] tracking-widest text-accent uppercase mb-3">Why work with me</p>
            <h2 className="font-semibold text-display-md text-bone-50 tracking-tightest">The right details matter.</h2>
          </div>
          <p className="max-w-sm text-sm text-bone-300 leading-relaxed">A considered edit does more than look good. It makes the message land, the story flow and the viewer stay.</p>
        </Reveal>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          {[
            ['STORY FIRST', 'Every cut has a reason.'],
            ['DETAIL OBSESSED', 'Small decisions change how an edit feels.'],
            ['BUILT FOR ATTENTION', 'The edit should earn the next second.'],
            ['COLLABORATIVE', 'The final video should match the creator or brand’s voice.'],
          ].map(([title, body], i) => (
            <Reveal key={title} delay={(i % 4) + 1} className="border-t border-white/15 pt-5">
              <h3 className="text-sm font-semibold tracking-wide text-bone-50 mb-3">{title}</h3>
              <p className="text-sm leading-relaxed text-bone-300">{body}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
