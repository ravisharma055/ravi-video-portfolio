import { services } from '@/data/portfolio';
import { Reveal } from './Reveal';

export function Services() {
  return (
    <section className="relative py-20 sm:py-28 lg:py-36 px-5 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-[1600px]">
        <Reveal className="mb-12 sm:mb-16">
          <p className="text-[11px] tracking-widest text-accent uppercase mb-3">
            What I Can Do
          </p>
        </Reveal>

        <div className="divide-y divide-white/8 border-y border-white/8">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={(i % 4) + 1}>
              <div className="group grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8 py-7 sm:py-9 hover:bg-ink-900/40 transition-colors duration-500 -mx-4 px-4 rounded-lg">
                <div className="md:col-span-1 font-mono text-sm text-bone-500 pt-1">
                  {String(i + 1).padStart(2, '0')}
                </div>
                <h3 className="md:col-span-5 font-semibold text-xl sm:text-2xl text-bone-50 tracking-tighter group-hover:text-accent transition-colors duration-300">
                  {s.title}
                </h3>
                <p className="md:col-span-6 text-bone-300 leading-relaxed text-[15px] md:pt-1.5">
                  {s.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
