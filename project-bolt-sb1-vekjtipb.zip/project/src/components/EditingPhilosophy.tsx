import { philosophy } from '@/data/portfolio';
import { Reveal } from './Reveal';

export function EditingPhilosophy() {
  return (
    <section className="relative py-24 sm:py-32 lg:py-40 px-5 sm:px-8 lg:px-12 border-y border-white/5 bg-ink-900/40">
      <div className="mx-auto max-w-[1600px]">
        <Reveal className="max-w-5xl">
          <p className="text-[11px] tracking-widest text-accent uppercase mb-5">
            Editing Philosophy
          </p>
          <h2 className="font-semibold text-display-lg text-bone-50 tracking-tightest text-balance leading-[0.95]">
            {philosophy.headline}
          </h2>
          <p className="mt-6 text-xl sm:text-2xl text-bone-300 font-light tracking-tight">
            {philosophy.sub}
          </p>
        </Reveal>

        <div className="mt-16 sm:mt-24 grid md:grid-cols-3 gap-px bg-white/5 rounded-xl overflow-hidden">
          {philosophy.principles.map((p, i) => (
            <Reveal
              key={p.index}
              delay={i + 1}
              className="bg-ink-950 p-8 sm:p-10 lg:p-12 group hover:bg-ink-900 transition-colors duration-500"
            >
              <span className="block font-mono text-sm text-accent mb-8">
                {p.index}
              </span>
              <h3 className="font-semibold text-2xl sm:text-3xl text-bone-50 tracking-tighter mb-3">
                {p.title}
              </h3>
              <p className="text-bone-300 leading-relaxed text-[15px]">
                {p.body}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
