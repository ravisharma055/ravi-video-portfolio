import { process } from '@/data/portfolio';
import { Reveal } from './Reveal';

export function Process() {
  return (
    <section className="relative py-20 sm:py-28 lg:py-36 px-5 sm:px-8 lg:px-12 border-t border-white/5">
      <div className="mx-auto max-w-[1600px]">
        <Reveal className="mb-14 sm:mb-20">
          <p className="text-[11px] tracking-widest text-accent uppercase mb-3">
            Process
          </p>
          <h2 className="font-semibold text-display-md text-bone-50 tracking-tightest max-w-3xl text-balance">
            From footage to final cut.
          </h2>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/5 rounded-xl overflow-hidden">
          {process.map((step, i) => (
            <Reveal
              key={step.index}
              delay={(i % 4) + 1}
              className="bg-ink-950 p-8 sm:p-10 group relative overflow-hidden"
            >
              <span className="block font-semibold text-display-md text-white/8 group-hover:text-accent/20 transition-colors duration-500 absolute -top-2 right-4 select-none">
                {step.index}
              </span>
              <div className="relative">
                <span className="font-mono text-sm text-accent mb-6 block">
                  {step.index}
                </span>
                <h3 className="font-semibold text-lg text-bone-50 tracking-tight mb-3">
                  {step.title}
                </h3>
                <p className="text-bone-300 leading-relaxed text-sm">
                  {step.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
