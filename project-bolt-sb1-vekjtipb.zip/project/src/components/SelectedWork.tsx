import { useRef, useState } from 'react';
import { ArrowUpRight, Play, X } from 'lucide-react';
import { type Project } from '@/data/portfolio';
import { useProjects } from '@/hooks/useProjects';
import { Reveal } from './Reveal';

function ProjectShowcase({
  project,
  number,
}: {
  project: Project;
  number: number;
}) {
  const [hovered, setHovered] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const reversed = number % 2 === 1;

  const handlePlay = () => {
    setVideoError(false);
    setPlaying(true);
    requestAnimationFrame(() => {
      videoRef.current?.play().catch(() => setVideoError(true));
    });
  };

  const handleClose = () => {
    setPlaying(false);
    setVideoError(false);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  return (
    <article
      id={project.id}
      className="group relative"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        className={`grid lg:grid-cols-12 gap-6 lg:gap-10 items-center ${
          reversed ? 'lg:[direction:rtl]' : ''
        }`}
      >
        {/* Media */}
        <div className="lg:col-span-8 [direction:ltr]">
          <div className="relative aspect-[16/10] rounded-xl overflow-hidden bg-ink-800">
            {/* Poster / thumbnail */}
            <img
              src={project.poster || project.thumbnail}
              alt={project.alt}
              loading="lazy"
              className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out-expo ${
                playing ? 'scale-105 opacity-0' : `opacity-100 ${hovered ? 'scale-105' : 'scale-100'}`
              }`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 via-transparent to-ink-950/10" />

            {/* Index watermark */}
            <span className="absolute top-5 left-5 text-[11px] tracking-widest text-bone-50/90 font-mono z-10">
              {project.index}
            </span>

            {/* Play button (only when not playing) */}
            {!playing && project.video && (
              <button
                onClick={handlePlay}
                aria-label={`Play ${project.title}`}
                className="absolute inset-0 flex items-center justify-center"
              >
                <div className="relative">
                  <span className="absolute inset-0 rounded-full bg-bone-50/10 animate-ping [animation-duration:3s]" />
                  <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-bone-50/95 backdrop-blur flex items-center justify-center group-hover:bg-accent group-hover:scale-110 transition-all duration-500 ease-out-expo">
                    <Play
                      className="w-6 h-6 sm:w-7 sm:h-7 text-ink-950 group-hover:text-bone-50 transition-colors"
                      fill="currentColor"
                    />
                  </div>
                </div>
              </button>
            )}

            {/* Hover label overlay */}
            {!playing && (
              <div
                className={`absolute inset-0 flex items-center justify-center transition-opacity duration-500 pointer-events-none ${
                  hovered ? 'opacity-0' : 'opacity-0'
                }`}
              >
                <div className="flex items-center gap-2 bg-bone-50 text-ink-950 text-[12px] tracking-widest font-medium uppercase px-5 py-3 rounded-full">
                  View Project
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            )}

            {/* Video player */}
            {playing && (
              <div className="absolute inset-0 bg-ink-950">
                {videoError ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-6 text-center">
                    <p className="text-sm tracking-wide text-bone-300 max-w-sm">
                      Video not available yet. Upload <span className="font-mono text-bone-100">{project.video}</span> to show this clip.
                    </p>
                    <button
                      onClick={handleClose}
                      className="inline-flex items-center gap-2 text-[12px] tracking-widest text-bone-200 hover:text-bone-50 uppercase"
                    >
                      <X className="w-4 h-4" /> Close
                    </button>
                  </div>
                ) : (
                  <>
                    <video
                      ref={videoRef}
                      src={project.video}
                      poster={project.poster || project.thumbnail}
                      preload="none"
                      controls
                      playsInline
                      onError={() => setVideoError(true)}
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    <button
                      onClick={handleClose}
                      aria-label="Close video"
                      className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-ink-950/70 backdrop-blur flex items-center justify-center text-bone-200 hover:text-bone-50 hover:bg-ink-950/90 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Info */}
        <div className="lg:col-span-4 [direction:ltr]">
          <p className="text-[11px] tracking-widest text-accent uppercase mb-3">
            {project.category}
          </p>
          <h3 className="font-semibold text-2xl sm:text-3xl text-bone-50 tracking-tighter mb-4">
            {project.title}
          </h3>
          <p className="text-sm sm:text-[15px] text-bone-300 leading-relaxed mb-5">
            {project.description}
          </p>

          <div className="space-y-2.5">
            {project.role && (
              <div className="flex gap-3 text-[12px]">
                <span className="text-bone-500 tracking-wide w-16 shrink-0">
                  Role
                </span>
                <span className="text-bone-200">{project.role}</span>
              </div>
            )}
            <div className="flex gap-3 text-[12px]">
              <span className="text-bone-500 tracking-wide w-16 shrink-0">
                Tools
              </span>
              <span className="text-bone-200">
                {project.tools.join(' · ')}
              </span>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}

export function SelectedWork() {
  const { projects } = useProjects();

  return (
    <section id="work" className="relative py-20 sm:py-28 lg:py-36 px-5 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-[1600px]">
        <Reveal className="mb-14 sm:mb-20 lg:mb-24">
          <p className="text-[11px] tracking-widest text-accent uppercase mb-3">
            Selected Work
          </p>
          <h2 className="font-semibold text-display-lg text-bone-50 tracking-tightest max-w-4xl text-balance">
            Different formats.
            <br />
            One goal — keep the viewer watching.
          </h2>
        </Reveal>

        <div className="space-y-20 sm:space-y-28 lg:space-y-36">
          {projects.map((p, i) => (
            <Reveal key={p.id} variant="scale">
              <ProjectShowcase project={p} number={i} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
