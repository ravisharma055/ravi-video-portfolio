import { ArrowUpRight, Mail } from 'lucide-react';
import { contact } from '@/data/portfolio';
import { Reveal } from './Reveal';

export function Contact() {
  return (
    <section id="contact" className="relative overflow-hidden py-28 sm:py-40 lg:py-52 px-5 sm:px-8 lg:px-12 grain">
      <div className="absolute -right-24 top-1/2 w-96 h-96 rounded-full bg-accent/10 blur-[120px] pointer-events-none" />
      <div className="relative mx-auto max-w-[1600px]">
        <Reveal>
          <p className="text-[11px] tracking-widest text-accent uppercase mb-6">Start a conversation</p>
          <h2 className="font-semibold text-display-lg text-bone-50 tracking-tightest leading-[0.92] max-w-5xl">
            {contact.headline.map((line) => <span key={line} className="block">{line}</span>)}
          </h2>
          <p className="mt-8 text-lg sm:text-xl text-bone-300 max-w-lg leading-relaxed">{contact.sub}</p>
          <a href={`mailto:${contact.email}`} className="mt-10 inline-flex items-center gap-3 rounded-full bg-accent text-bone-50 px-6 py-4 text-sm tracking-wide font-medium hover:bg-accent-soft transition-colors duration-300">
            <Mail className="w-4 h-4" /> {contact.cta} <ArrowUpRight className="w-4 h-4" />
          </a>
          <div className="mt-16 flex items-center gap-6">
            {contact.socials.map((social) => <a key={social.label} href={social.href} className="text-xs tracking-widest uppercase text-bone-300 hover:text-bone-50 transition-colors">{social.label}</a>)}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
