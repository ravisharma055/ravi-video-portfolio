import { type ReactNode, type RefObject } from 'react';
import { useReveal } from '@/hooks/useReveal';

type RevealProps = {
  children: ReactNode;
  className?: string;
  variant?: 'up' | 'scale';
  delay?: number | '1' | '2' | '3' | '4' | '5';
  as?: 'div' | 'section' | 'li' | 'span';
};

export function Reveal({
  children,
  className = '',
  variant = 'up',
  delay,
  as = 'div',
}: RevealProps) {
  const { ref, visible } = useReveal();
  const base = variant === 'scale' ? 'reveal-scale' : 'reveal';
  const delayClass = delay ? `delay-${delay}` : '';
  const Tag = as as 'div';

  return (
    <Tag
      ref={ref as RefObject<HTMLDivElement>}
      className={`${base} ${delayClass} ${visible ? 'is-visible' : ''} ${className}`}
    >
      {children}
    </Tag>
  );
}
