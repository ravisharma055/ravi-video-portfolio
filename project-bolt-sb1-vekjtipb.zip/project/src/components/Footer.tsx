import { ArrowUpRight } from 'lucide-react';
import { nav } from '@/data/portfolio';

export function Footer() {
  return (
    <footer className="border-t border-white/10 px-5 sm:px-8 lg:px-12 py-8 sm:py-10">
      <div className="mx-auto max-w-[1600px] flex flex-col gap-8 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <a href="#top" className="font-semibold text-bone-50 tracking-tighter text-lg">{nav.name}</a>
          <p className="mt-1 text-[10px] tracking-widest text-bone-500 uppercase">{nav.role}</p>
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-[11px] tracking-widest text-bone-400 uppercase">
          {nav.links.map((link) => <a key={link.href} href={link.href} className="hover:text-bone-50 transition-colors">{link.label}</a>)}
          <a href="#contact" className="inline-flex items-center gap-1 text-bone-200 hover:text-accent transition-colors">Let’s talk <ArrowUpRight className="w-3 h-3" /></a>
        </div>
        <p className="text-[10px] tracking-wide text-bone-500">© 2026 Ravi Sharma</p>
      </div>
    </footer>
  );
}
