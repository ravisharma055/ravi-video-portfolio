import { useEffect, useState } from 'react';
import { nav } from '@/data/portfolio';

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ease-out-expo ${
        scrolled
          ? 'bg-ink-950/80 backdrop-blur-xl border-b border-white/5'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <nav className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12 h-16 flex items-center justify-between">
        {/* Left — identity */}
        <a href="#top" className="group flex items-baseline gap-3 leading-none">
          <span className="font-semibold tracking-tighter text-bone-50 text-[15px] sm:text-base">
            {nav.name}
          </span>
          <span className="hidden sm:inline text-[10px] tracking-widest text-bone-400 uppercase">
            {nav.role}
          </span>
        </a>

        {/* Right — links */}
        <div className="hidden md:flex items-center gap-9">
          {nav.links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-[13px] tracking-wide text-bone-200 hover:text-bone-50 transition-colors duration-300"
            >
              {l.label}
            </a>
          ))}
          <a
            href={nav.cta.href}
            className="text-[12px] tracking-widest font-medium text-ink-950 bg-bone-50 hover:bg-accent hover:text-bone-50 px-4 py-2 rounded-full transition-colors duration-300"
          >
            {nav.cta.label}
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
          className="md:hidden flex flex-col gap-[5px] w-7 h-7 items-center justify-center"
        >
          <span
            className={`block h-[1.5px] w-5 bg-bone-100 transition-transform duration-300 ${
              open ? 'translate-y-[3.5px] rotate-45' : ''
            }`}
          />
          <span
            className={`block h-[1.5px] w-5 bg-bone-100 transition-transform duration-300 ${
              open ? '-translate-y-[3.5px] -rotate-45' : ''
            }`}
          />
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-500 ease-out-expo ${
          open ? 'max-h-80' : 'max-h-0'
        }`}
      >
        <div className="px-5 pb-6 pt-2 flex flex-col gap-1 bg-ink-950/95 backdrop-blur-xl border-b border-white/5">
          {nav.links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="py-3 text-sm tracking-wide text-bone-200 hover:text-bone-50 border-b border-white/5"
            >
              {l.label}
            </a>
          ))}
          <a
            href={nav.cta.href}
            onClick={() => setOpen(false)}
            className="mt-4 text-center text-[12px] tracking-widest font-medium text-ink-950 bg-bone-50 px-4 py-3 rounded-full"
          >
            {nav.cta.label}
          </a>
        </div>
      </div>
    </header>
  );
}
