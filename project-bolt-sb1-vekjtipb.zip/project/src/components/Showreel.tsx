import { useRef, useState } from 'react';
import { Play, X } from 'lucide-react';
import { showreel } from '@/data/portfolio';
import { Reveal } from './Reveal';

export function Showreel() {
  const [playing, setPlaying] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <section
      id="showreel"
      className="relative py-20 sm:py-28 lg:py-36 px-5 sm:px-8 lg:px-12"
    >
      <div className="mx-auto max-w-[1600px]">
        <Reveal className="flex items-end justify-between gap-6 mb-8 sm:mb-12">
          <div>
            <p className="text-[11px] tracking-widest text-accent uppercase mb-3">
              {showreel.title}
            </p>
            <h2 className="font-semibold text-display-md text-bone-50 tracking-tighter max-w-2xl">
              The reel.
            </h2>
          </div>
          <p className="hidden sm:block max-w-xs text-sm text-bone-300 leading-relaxed text-right">
            {showreel.subtitle}
          </p>
        </Reveal>

        <Reveal variant="scale">
          <div
            ref={containerRef}
            className="group relative aspect-[16/9] sm:aspect-[21/9] w-full rounded-2xl overflow-hidden cursor-pointer bg-ink-800"
            onClick={() => !playing && setPlaying(true)}
          >
            {/* Poster */}
            <img
              src={showreel.poster}
              alt={showreel.alt}
              loading="lazy"
              className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out-expo ${
                playing ? 'scale-105 opacity-0' : 'opacity-100 group-hover:scale-105'
              }`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-ink-950/20 to-ink-950/30" />

            {/* Play button */}
            {!playing && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative">
                  <span className="absolute inset-0 rounded-full bg-bone-50/10 animate-ping [animation-duration:3s]" />
                  <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-bone-50/95 backdrop-blur flex items-center justify-center group-hover:bg-accent group-hover:scale-110 transition-all duration-500 ease-out-expo">
                    <Play
                      className="w-6 h-6 sm:w-7 sm:h-7 text-ink-950 group-hover:text-bone-50 transition-colors"
                      fill="currentColor"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Caption */}
            {!playing && (
              <div className="absolute bottom-0 inset-x-0 p-6 sm:p-8 lg:p-10 flex items-end justify-between">
                <div>
                  <p className="text-[10px] tracking-widest text-bone-300 uppercase mb-1.5">
                    Selected Reel — 2026
                  </p>
                  <p className="text-lg sm:text-xl text-bone-50 font-medium">
                    Motion · Rhythm · Visual Storytelling
                  </p>
                </div>
                <span className="text-[11px] tracking-widest text-bone-400 uppercase hidden sm:block">
                  01:32
                </span>
              </div>
            )}

            {/* Video placeholder overlay when "playing" */}
            {playing && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 bg-ink-950">
                <p className="text-sm tracking-wide text-bone-300 max-w-sm text-center px-6">
                  Video player placeholder — drop your reel here. Replace the
                  poster and add a video source to go live.
                </p>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setPlaying(false);
                  }}
                  className="inline-flex items-center gap-2 text-[12px] tracking-widest text-bone-200 hover:text-bone-50 uppercase"
                >
                  <X className="w-4 h-4" /> Close
                </button>
              </div>
            )}
          </div>
        </Reveal>

        <p className="sm:hidden mt-5 text-sm text-bone-300 leading-relaxed">
          {showreel.subtitle}
        </p>
      </div>
    </section>
  );
}
