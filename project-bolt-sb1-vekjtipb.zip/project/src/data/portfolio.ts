export type Project = {
  id: string;
  index: string;
  title: string;
  category: string;
  description: string;
  tools: string[];
  thumbnail: string;
  alt: string;
  video?: string;
  poster?: string;
  role?: string;
};

export const projects: Project[] = [
  {
    id: 'timesphysio',
    index: '01',
    title: 'TimesPhysio',
    category: 'CLIENT WORK',
    description:
      'Edited video content for TimesPhysio — structured around clear messaging, clean pacing and a tone that fits a healthcare audience.',
    tools: ['DaVinci Resolve', 'After Effects'],
    thumbnail: '/portfolio/timesphysio.jpg',
    poster: '/portfolio/timesphysio.jpg',
    video: '/portfolio/timesphysio.mp4',
    alt: 'Physiotherapist treating a patient\u2019s hand',
    role: 'Edit · Captions · Grade',
  },
  {
    id: 'doctor-content',
    index: '02',
    title: 'Doctor Content',
    category: 'CLIENT WORK',
    description:
      'Talking-head edits for a doctor\u2019s channel — tightening the delivery, adding B-roll, captions and motion to keep the message clear and watchable.',
    tools: ['DaVinci Resolve', 'Photoshop'],
    thumbnail: '/portfolio/doctor.jpg',
    poster: '/portfolio/doctor.jpg',
    video: '/portfolio/doctor.mp4',
    alt: 'Doctor reviewing a chest X-ray',
    role: 'Edit · B-roll · Captions',
  },
  {
    id: 'podcast-edit',
    index: '03',
    title: 'Podcast Edit',
    category: 'PODCAST',
    description:
      'Full podcast edit — cleaning up the conversation, pacing the cuts, and building a rhythm that carries the dialogue without losing the natural flow.',
    tools: ['DaVinci Resolve'],
    thumbnail: '/portfolio/podcast.jpg',
    poster: '/portfolio/podcast.jpg',
    video: '/portfolio/podcast.mp4',
    alt: 'Professional microphone in a dim recording studio',
    role: 'Edit · Sound · Pacing',
  },
  {
    id: '3d-motion',
    index: '04',
    title: '3D Motion Graphic',
    category: 'MOTION DESIGN',
    description:
      'A 3D motion graphics piece built around form, light and movement — designed to show how motion can carry an idea on its own.',
    tools: ['After Effects', 'DaVinci Resolve'],
    thumbnail: '/portfolio/3d-motion.jpg',
    poster: '/portfolio/3d-motion.jpg',
    video: '/portfolio/3d-motion.mp4',
    alt: 'Abstract 3D geometric shapes in a dark render',
    role: 'Motion · 3D · Compositing',
  },
  {
    id: 'talking-head-tutorial',
    index: '05',
    title: 'Talking Head / Tutorial',
    category: 'TUTORIAL',
    description:
      'Tutorial-style talking-head edit — clear structure, paced explanations, captions and motion that help the viewer follow each step.',
    tools: ['DaVinci Resolve', 'After Effects'],
    thumbnail: '/portfolio/tutorial.jpg',
    poster: '/portfolio/tutorial.jpg',
    video: '/portfolio/tutorial.mp4',
    alt: 'Video editing timeline on a computer screen',
    role: 'Edit · Captions · Motion',
  },
  {
    id: 'car-edit',
    index: '06',
    title: 'Car Edit',
    category: 'PERSONAL / EXPERIMENTAL',
    description:
      'A personal, experimental car edit — focused on rhythm, sound design and visual pacing, built to push how motion and music work together.',
    tools: ['DaVinci Resolve', 'After Effects'],
    thumbnail: '/portfolio/car.jpg',
    poster: '/portfolio/car.jpg',
    video: '/portfolio/car.mp4',
    alt: 'Person standing near a car at night with glowing lights',
    role: 'Edit · Sound Design · Grade',
  },
];

export const showreel = {
  title: 'SELECTED REEL',
  subtitle:
    'A glimpse into how I approach motion, rhythm and visual storytelling.',
  poster:
    'https://images.pexels.com/photos/4086274/pexels-photo-4086274.jpeg?auto=compress&cs=tinysrgb&w=1920',
  alt: 'Editor working at a desk with multiple screens in a studio',
  video: '',
};

export const philosophy = {
  headline: 'GOOD EDITING ISN\u2019T ABOUT ADDING MORE.',
  sub: 'It\u2019s about knowing what deserves to stay.',
  principles: [
    {
      index: '01',
      title: 'HOOK',
      body: 'Give the viewer a reason to stay.',
    },
    {
      index: '02',
      title: 'RHYTHM',
      body: 'Control attention through timing, pacing and sound.',
    },
    {
      index: '03',
      title: 'PAYOFF',
      body: 'Make every visual choice serve the story.',
    },
  ],
};

export const services = [
  {
    title: 'SHORT-FORM EDITING',
    body: 'Reels, Shorts and social-first content designed around retention.',
  },
  {
    title: 'TALKING HEAD',
    body: 'Clean cuts, visual pacing, B-roll, captions and motion.',
  },
  {
    title: 'PODCAST EDITING',
    body: 'Conversation-led edits with clean pacing, sound and flow.',
  },
  {
    title: 'MOTION DESIGN',
    body: 'Motion graphics, 3D and compositing built around intent.',
  },
];

export const process = [
  {
    index: '01',
    title: 'UNDERSTAND',
    body: 'Understand the content, audience and goal.',
  },
  {
    index: '02',
    title: 'SHAPE',
    body: 'Find the story, structure and strongest moments.',
  },
  {
    index: '03',
    title: 'DESIGN',
    body: 'Build pacing, sound, motion and visual language.',
  },
  {
    index: '04',
    title: 'REFINE',
    body: 'Polish every detail and prepare the final deliverable.',
  },
];

export const whyRavi = [
  {
    title: 'STORY FIRST',
    body: 'Every cut has a reason.',
  },
  {
    title: 'DETAIL OBSESSED',
    body: 'Small decisions change how an edit feels.',
  },
  {
    title: 'BUILT FOR ATTENTION',
    body: 'The edit should earn the next second.',
  },
  {
    title: 'COLLABORATIVE',
    body: 'The final video should match the creator or brand\u2019s voice.',
  },
];

export const about = {
  headline: 'THE EDITOR BEHIND THE CUT.',
  body: [
    'I\u2019m Ravi Sharma, a video editor focused on turning raw footage and ideas into engaging visual stories.',
    'I care about the details that make an edit feel intentional \u2014 timing, sound, composition, motion and the moments that keep people watching.',
  ],
  tools: ['DaVinci Resolve', 'After Effects', 'Photoshop'],
  portrait:
    'https://images.pexels.com/photos/35964824/pexels-photo-35964824.jpeg?auto=compress&cs=tinysrgb&w=1200',
  alt: 'Side profile portrait of a man with dramatic lighting',
};

export const contact = {
  headline: ['HAVE SOMETHING', 'WORTH WATCHING?'],
  sub: 'Let\u2019s turn the footage into something people remember.',
  cta: 'START A PROJECT',
  email: 'hello@ravisharma.edit',
  socials: [
    { label: 'LinkedIn', href: '#' },
    { label: 'X', href: '#' },
  ],
};

export const nav = {
  name: 'RAVI SHARMA',
  role: 'VIDEO EDITOR',
  links: [
    { label: 'WORK', href: '#work' },
    { label: 'ABOUT', href: '#about' },
    { label: 'CONTACT', href: '#contact' },
  ],
  cta: { label: "LET\u2019S TALK", href: '#contact' },
};
